using RPG.Common;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using RPG.UI;
using RPG.Utils;
using RPG.Input;

public partial class Player : Singleton<Player>, IDamageable, IStatus
{
    #region IStatus Implements
    public StructStatus Status { get; private set; }

    public int Atk { get; private set; }
    public int Def { get; private set; }
    public int MaxHp { get; private set; }
    public int MaxMp { get; private set; }

    public void UpdateStatus()
    {
        int headItemIndex = _humanEquipSlots.HeadIndex;
        int chestIndex = _humanEquipSlots.ChestIndex;
        int handIndex0 = _humanEquipSlots.HandIndex0;
        int handIndex1 = _humanEquipSlots.HandIndex1;
        int footIndex = _humanEquipSlots.FootIndex;

        int[] equips = { headItemIndex, chestIndex, handIndex0, handIndex1, footIndex };

        TotalStr = Status.Str;
        TotalEnd = Status.End;
        TotalSta = Status.Sta;
        TotalMag = Status.Mag;

        int equipAtk = 0;
        int equipDef = 0;
        int equipMaxHp = 0;
        int equipMaxMp = 0;

        for (int i = 0; i < equips.Length; i++)
        {
            int slotIndex = equips[i];

            if (slotIndex == -1)
                continue;

            int itemId = Items[slotIndex].ItemId;
            
            if (itemId == -1)
                continue;

            StructItemData equipData = DataBase.Items[itemId];

            TotalStr += equipData.Str;
            TotalEnd += equipData.End;
            TotalSta += equipData.Sta;
            TotalMag += equipData.Mag;

            equipAtk += equipData.Attack;
            equipDef += equipData.Defence;
            equipMaxHp += equipData.MaxHp;
            equipMaxMp += equipData.MaxMp;
        }

        (Atk, Def, MaxHp, MaxMp) = Calculate.RealStatus(TotalStr, TotalEnd, TotalSta, TotalMag);

        Atk += equipAtk;
        Def += equipDef;
        MaxHp += equipMaxHp;
        MaxMp += equipMaxMp;

        Debug.Log("_attackCollider.SetDamage : " + Atk);
        _attackCollider.SetDamage(Atk); ;
        IsChangedStatus = true;
        Debug.Log("IsChangedStatus " + IsChangedStatus);
    }
    #endregion
    public int TotalStr { get; private set; }
    public int TotalEnd { get; private set; }
    public int TotalSta { get; private set; }
    public int TotalMag { get; private set; }

    #region IDamageable Implements
    public void OnDamage(int damageAmount)
    {
        //Debug.Log("Player is Hit!!!");
        //Debug.Log($"Player Hp : {Hp} -> {Hp - damageAmount}");
        Hp -= damageAmount;

        if (Hp <= 0f)
        {
            OnDeath();
        }
    }

    public void OnDeath()
    {
        throw new System.NotImplementedException();
    }
    #endregion

    #region Hp, Mp
    public int _hp;
    public int Hp
    {
        get => _hp;
        private set
        {
            _hp = value < 0 ? 0 : value;
            float rate = (float)_hp / MaxHp;
            @UIManager.UpdateHpGauge(rate);
        }
    }

    public int _mp;
    public int Mp
    {
        get => _mp;
        private set
        {
            _mp = value < 0 ? 0 : value;
            float rate = (float)_mp / MaxMp;
            @UIManager.UpdateMpGauge(rate);
        }
    }
    #endregion

    public AttackCollider _attackCollider;
    public Animator _anim;
    public UIManager @UIManager;

    public CustomThirdPersonController _controller;

    public bool IsChangedStatus { get; set; }

    public override void Initialize()
    {
        @UIManager = UIManager.Instance;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag(StringStatic.MonsterAttackEffectTag))
        {
            AttackCollider monsterAttackCollider = other.GetComponent<AttackCollider>();
            if(monsterAttackCollider != null)
            {
                int realDamage = Calculate.RealDamage(monsterAttackCollider.Damage, Def);

                if (realDamage > 0)
                {
                    //Debug.Log("Player take Damage : " + monsterAttackCollider.Damage);
                    //Debug.Log("Playe Def : " + Def);
                    //Debug.Log("Player take realDamage : " + realDamage);

                    if (_controller.IsBlocking)
                    {
                        Debug.Log("Block!!!");
                        OnDamage(0);
                    }
                    else
                    {
                        OnDamage(realDamage);
                    }
                }
                else
                {
                    OnDamage(0);
                }
            }
        }
    }

    public void LoadPlayerData(StructPlayerData playerData)
    {
        _structInventory = playerData.Inventory;
        _structInventory.Items = new StructInventorySlot[playerData.Inventory.InventorySlotNumber];

        for(int i = 0; i < _structInventory.Items.Length; i++)
        {
            _structInventory.Items[i] = new StructInventorySlot(-1, 0, i, false);
        }

        for (int i = 0; i < playerData.Inventory.Items.Length; i++)
        {
            StructInventorySlot loadedItem = playerData.Inventory.Items[i];

            if(loadedItem.SlotIndex >= _structInventory.Items.Length)
            {
                throw new System.Exception("loadedItem.SlotIndex >= _structInventory.Items.Length");
            }

            AddItem(loadedItem.SlotIndex, loadedItem.ItemId, loadedItem.ItemCount);
        }

        //Debug.Log("_structInventory:" + _structInventory);
        //Debug.Log("playerData.Status:" + playerData.Status);
        Status = playerData.Status;
        _humanEquipSlots = playerData.HumanEquipSlots;

        Debug.Log("LoadPlayerData");

        UpdateStatus();
    }

    public void AddExperience(int experienceAmount)
    {
        int currentExperience = Status.Experience;
        currentExperience += experienceAmount;
        Status.SetExperience(currentExperience);
    }
    
    void Start()
    {
        RecoveryAll();

        //Debug.Log("Atk " + Atk);
        //Debug.Log("Hp " + Hp);
        //Debug.Log("MaxHp " + MaxHp);
    }

    private void RecoveryAll()
    {
        Hp = MaxHp;
        Mp = MaxMp;
    }
}
