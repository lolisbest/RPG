using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using RPG.Common;
using RPG.UI;

public class GameManager : Singleton<GameManager>
{
    public UIManager @UIManager;
    public QuestManager @QuestManager;
    public ItemDropper @ItemDropper;
    public Player @Player;
    public DamageTextDrawer @DamageTextDrawer;
    private void Awake()
    {
        Application.targetFrameRate = -1;

        Debug.Log("GameManager.Awake()");
        Singleton.InitQuitting();

        InteractableObject.SetLayerMaskValue();
        DataBase.Initialize();

        @UIManager = UIManager.Instance;
        @QuestManager = QuestManager.Instance;
        @ItemDropper = ItemDropper.Instance;

        @UIManager.Initialize();
        @QuestManager.Initialize();

        @Player = Player.Instance;
        @Player.LoadPlayerData(DataBase.Players[0]);
        @Player.Initialize();

        @DamageTextDrawer = DamageTextDrawer.Instance;
        @DamageTextDrawer.Initialize();
        //PlayerData.Initialize();
        //PlayerData.Load();
        // ------------------------------------------


        //NpcDataLoad.Initialize();
        //NpcDataLoad.Load();

        //QuestDataLoad.Initialize();
        //QuestDataLoad.Load();

        Debug.Log("Application.targetFrameRate:" + Application.targetFrameRate);
    }

    void Start()
    {
        //CurrentPayerData.AddItem(13, 10);
        //UIManager.Instance.OpenInventoryWindow();
    }

    public override void Initialize()
    {
        throw new System.NotImplementedException();
    }
}
