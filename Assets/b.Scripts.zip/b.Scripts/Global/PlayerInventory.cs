using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using RPG.Common;
using RPG.UI;


public partial class Player
{
    [SerializeField]
    private StructInventory _structInventory;
    public StructInventorySlot[] Items { get => _structInventory.Items; }

    [SerializeField]
    private StructHumanEquipSlots _humanEquipSlots;

    private bool _isChangedInventory;
    /// <summary>
    /// true가 할당되면 UpdateStatus 호출
    /// </summary>
    public bool IsChangedInventory
    {
        get => _isChangedInventory;
        set
        {
            _isChangedInventory = value;
        }
    }

    public int Money { get => _structInventory.Money; }

    public static bool UseItem(int itemSlotIndex)
    {
        return false;
    }

    public bool Pay(int moneyAmount)
    {
        if (_structInventory.Money - moneyAmount >= 0)
        {
            _structInventory.Money -= moneyAmount;
            IsChangedInventory = true;
            return true;
        }

        return false;
    }

    /// <summary>
    /// 아이템의 유형에 따라 단일 혹은 묶음 형태로 저장
    /// </summary>
    /// <param name="itemId"></param>
    /// <param name="itemCount"></param>
    /// <returns></returns>
    public bool AddItem(int itemId, int itemCount)
    {
        // 빈 슬롯 찾기
        int addIndex = GetEmptySlotIndex();

        // 묶을 수 있는 아이템인지?
        if (
            DataBase.Items[itemId].Type == ItemType.Consumable ||
            DataBase.Items[itemId].Type == ItemType.Etc
            )
        {
            // 묶음 아이템이면, 인벤토리에 존재하는 동일한 아이템 찾기
            int sameItemIndex = GetSameItemSlotIndex(itemId);
            if (sameItemIndex == -1)
            {
                if (addIndex == -1)
                {
                    // 동일한 묶음 아이템이 없어서 새로운 슬롯을 사용해야하고
                    // 빈 슬롯이 없을 떄
                    return false;
                }

                // 동일한 아이템이 없다면 빈 슬롯에 아이템 추가
                _structInventory.Items[addIndex].ItemId = itemId;
                _structInventory.Items[addIndex].ItemCount = itemCount;
            }
            else
            {
                // 동일한 아이템에 개수 추가
                _structInventory.Items[sameItemIndex].ItemCount += itemCount;
            }
        }
        else
        {
            if (addIndex == -1)
            {
                // 묶을 수 없는 아이템이고
                // 빈 슬롯이 없을 떄
                return false;
            }

            // 묶음 아이템이 아니므로 빈 슬롯에 추가
            _structInventory.Items[addIndex].ItemId = itemId;
            _structInventory.Items[addIndex].ItemCount = itemCount;
        }

        IsChangedInventory = true;
        return true;
    }

    /// <summary>
    /// 특정 슬롯에 아이템 추가, 슬롯이 사용 중이라면 빈 슬롯에 추가
    /// </summary>
    /// <param name="itemSlotIndex"></param>
    /// <param name="itemId"></param>
    /// <param name="itemCount"></param>
    /// <returns></returns>
    public bool AddItem(int itemSlotIndex, int itemId, int itemCount)
    {
        if (_structInventory.Items[itemSlotIndex].ItemId != -1)
        {
            // 이미 사용 중인 아이템 슬롯
            // 다른 임의의 슬롯에 저장
            return AddItem(itemId, itemCount);
        }

        // 사용 중인 슬롯이 아니므로 아이템 추가
        _structInventory.Items[itemSlotIndex].ItemId = itemId;
        _structInventory.Items[itemSlotIndex].ItemCount = itemCount;
        IsChangedInventory = true;
        return true;
    }

    public bool CreateSlots(int inventoryLength)
    {
        // 이 메서드를 인벤토리 공간을 축소시키는 용도로 사용할 경우 문제가 발생.
        // 그리고 게임 도중에 사용할 경우 기존의 아이템이 사라짐. 반드시 게임 실행 시작에만 사용 할 것.

        _structInventory.Items = new StructInventorySlot[inventoryLength];
        _structInventory.InventorySlotNumber = inventoryLength;

        for (int i = 0; i < inventoryLength; i++)
        {
            _structInventory.Items[i] = new StructInventorySlot() { ItemId = -1, ItemCount = 0, SlotIndex = i };
        }

        IsChangedInventory = true;
        return true;
    }

    public bool AddMoney(int moneyAmount)
    {
        if (_structInventory.Money + moneyAmount > _structInventory.MaxMoney)
        {
            Debug.Log($"{_structInventory.Money + moneyAmount - _structInventory.MaxMoney} 골드를 소지하지 못 합니다.");
            // 다르면 변화가 있음 -> true
            IsChangedInventory = _structInventory.Money != _structInventory.MaxMoney;
            _structInventory.Money = _structInventory.MaxMoney;
            return false;
        }

        _structInventory.Money += moneyAmount;
        IsChangedInventory = true;
        return true;
    }

    private int GetEmptySlotIndex()
    {
        for (int i = 0; i < _structInventory.Items.Length; i++)
        {
            if (_structInventory.Items[i].ItemId == -1)
            {
                return i;
            }
        }

        return -1;
    }

    private int GetSameItemSlotIndex(int itemId)
    {
        for (int i = 0; i < _structInventory.Items.Length; i++)
        {
            if (itemId == _structInventory.Items[i].ItemId)
            {
                return i;
            }
        }

        return -1;
    }

    /// <summary>
    /// 사용 실패는 -1, 사용 성공 시 소모용 아이템의 남은 개수 반환
    /// </summary>
    /// <param name="slotIndex"></param>
    /// <returns></returns>
    public int ConsumeItem(int slotIndex)
    {
        Debug.Log("ConsumeItem");

        int itemId = _structInventory.Items[slotIndex].ItemId;
        StructItemData itemData = DataBase.Items[itemId];

        if (itemData.RecoveryHpAmount > 0 && Hp >= MaxHp)
        {
            // 사용 실패
            Debug.Log($"Fail to use `{itemData.Name}`. Already Hp is full.");
            return -1;
        }

        if (itemData.RecoveryMpAmount > 0 && Mp >= MaxMp)
        {
            // 사용 실패
            Debug.Log($"Fail to use `{itemData.Name}`. Already Mp is full.");
            return -1;
        }

        Hp += itemData.RecoveryHpAmount;
        Mp += itemData.RecoveryMpAmount;

        _structInventory.Items[slotIndex].ItemCount -= 1;

        IsChangedInventory = true;

        if (_structInventory.Items[slotIndex].ItemCount == 0)
        {
            RemoveItem(slotIndex);
            @UIManager.CLoseInventoryItemInfoWindow();
        }

        return _structInventory.Items[slotIndex].ItemCount;
    }

    private void RemoveItem(int slotIndex)
    {
        _structInventory.Items[slotIndex].ItemId = -1;
        _structInventory.Items[slotIndex].ItemCount = 0;
        IsChangedInventory = true;
    }

    public void EquipItem(int slotIndex)
    {
        int itemId = Items[slotIndex].ItemId;
        if (itemId == -1)
            return;

        StructItemData itemData = DataBase.Items[itemId];
        if (itemData.Type != ItemType.Equipment)
        {
            return;
            throw new Exception($"Not Equipment. slot : {slotIndex}, item Name : {itemData.Name}, Type : {itemData.Type}");
        }

        int previousEquipSlotIndex;

        switch (itemData.EquipPartType)
        {
            case EquipType.Head:
                previousEquipSlotIndex = _humanEquipSlots.HeadIndex;
                _humanEquipSlots.HeadIndex = slotIndex;
                break;
            case EquipType.Chest:
                previousEquipSlotIndex = _humanEquipSlots.ChestIndex;
                _humanEquipSlots.ChestIndex = slotIndex;
                break;
            case EquipType.Hand0:
                previousEquipSlotIndex = _humanEquipSlots.HandIndex0;
                _humanEquipSlots.HandIndex0 = slotIndex;
                break;
            case EquipType.Hand1:
                previousEquipSlotIndex = _humanEquipSlots.HandIndex1;
                _humanEquipSlots.HandIndex1 = slotIndex;
                break;
            case EquipType.Foot:
                previousEquipSlotIndex = _humanEquipSlots.FootIndex;
                _humanEquipSlots.FootIndex = slotIndex;
                break;
            default:
                throw new Exception($"Equip Fail. Unknown EquipType. slot : {slotIndex}, item Name : {itemData.Name}, EquipType : {itemData.EquipPartType}");
        }

        if (previousEquipSlotIndex != -1)
        {
            Items[previousEquipSlotIndex].IsOnEquip = false;
        }

        Items[slotIndex].IsOnEquip = true;
        IsChangedInventory = true;

        UpdateStatus();
    }

    public void UnequipItem(int slotIndex)
    {
        int itemId = Items[slotIndex].ItemId;
        if(itemId == -1)
        {
            return;
        }

        StructItemData itemData = DataBase.Items[itemId];
        if (itemData.Type != ItemType.Equipment)
        {
            return;
            throw new Exception($"Current Equipment is not equipment. slot : {slotIndex}, item Name : {itemData.Name}, Type : {itemData.Type}");
        }

        Debug.Log($"UnequipItem : {itemData.Name}");
        Debug.Log($"UnequipItem : {itemData.EquipPartType}");

        switch (itemData.EquipPartType)
        {
            case EquipType.Head:
                _humanEquipSlots.HeadIndex = -1;
                break;
            case EquipType.Chest:
                _humanEquipSlots.ChestIndex = -1;
                break;
            case EquipType.Hand0:
                _humanEquipSlots.HandIndex0 = -1;
                break;
            case EquipType.Hand1:
                _humanEquipSlots.HandIndex1 = -1;
                break;
            case EquipType.Foot:
                _humanEquipSlots.FootIndex = -1;
                break;
            default:
                throw new Exception($"Unquip Fail. Unknown EquipType. slot : {slotIndex}, item Name : {itemData.Name}, EquipType : {itemData.EquipPartType}");
        }

        Debug.Log("_humanEquipSlots " + _humanEquipSlots);

        Items[slotIndex].IsOnEquip = false;
        IsChangedInventory = true;
        UpdateStatus();
    }

    public void SwapItemSlot(int leftSlotIndex, int rightSlotIndex)
    {
        Debug.Log($"Swap {leftSlotIndex} <-> {rightSlotIndex}");
        StructInventorySlot leftSlot = Items[leftSlotIndex];
        StructInventorySlot rightSlot = Items[rightSlotIndex];

        UnequipItem(leftSlotIndex);
        UnequipItem(rightSlotIndex);

        Items[leftSlotIndex] = rightSlot;
        Items[rightSlotIndex] = leftSlot;

        Debug.Log($"leftSlot:{leftSlot} {leftSlot.IsOnEquip}");
        Debug.Log($"rightSlot:{rightSlot} {rightSlot.IsOnEquip}");

        if(leftSlot.IsOnEquip)
        {
            EquipItem(rightSlotIndex);
        }
        
        if(rightSlot.IsOnEquip)
        {
            EquipItem(leftSlotIndex);
        }


        IsChangedInventory = true;
    }
}
