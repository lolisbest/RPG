using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using RPG.Item;
using RPG.Common;

using ItemId = System.Int32;


public static partial class DataBase
{
    private class ItemDataBase : IDataLoad
    {
        public string DataFileName { get; private set; } = "ItemDataBase";
        public static Dictionary<ItemId, StructItemData> Items { get; private set; }
        // ������ ���� �������� ����� ItemId ���
        private static List<int> _itemIds;

        /// <summary>
        /// ItemDataBase.json�� �о� ���̱�
        /// </summary>
        public void Load()
        {
            if (Items == null || _itemIds == null)
                throw new System.Exception("�ʱ�ȭ ���� ���� Items or _itemIds");

            string filePath = DataRootDirPath + DataFileName;
            StructItemData[] itemDataArray = RPG.Utils.ReadJson.Read<StructItemData>(filePath);
            foreach (var itemData in itemDataArray)
            {
                //Debug.Log(itemData.ToString());
                itemData.LoadSprite();
                itemData.SetType();
                try
                {
                    Items.Add(itemData.Id, itemData);

                }
                catch (System.ArgumentException e)
                {
                    Debug.Log(string.Join(",", Items.Keys));
                    throw new System.Exception(e.Message);
                }
            }
            Debug.Log($"Loaded {Items.Count}/{itemDataArray.Length} of Items from {DataFileName}");
        }

        /// <summary>
        /// Items, _itemIds �ʱ�ȭ
        /// </summary>
        public IDataLoad Initialize()
        {
            Items = new();
            _itemIds = new();
            return this;
        }

        //public int GenerateRandomItem()
        //{
        //    int index = Item.Rand.Next(Items.Count);
        //    int id = _itemIds[index];
        //    return id
        //}

        //public Item GetItemFromItemId(int id)
        //{
        //    Item item = new(Items[id]);
        //    return item;
        //}
    }
}
