using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using RPG.Common;
using System.Linq;

public interface IDataLoad
{
    public string DataFileName { get; }

    public IDataLoad Initialize();

    public void Load();
}

public static partial class DataBase
{
    // XXXDataBase�� IDataLoad�� ��� �ޱ� ������ static���� ������ �� ����
    // ���� _XXXDataBase ��ü�� �����Ͽ� Initialize, Load�� ȣ���ؾ� ��
    public static string DataRootDirPath { get; private set; } = "JsonData/";

    private static ItemDataBase _itemDataBase;
    // <Item Id, StructItemData>
    public static Dictionary<int, StructItemData> Items { get => ItemDataBase.Items; }

    private static NpcDataBase _npcDataBase;
    public static Dictionary<int, StructNpcData> Npcs { get => NpcDataBase.Npcs; }

    private static QuestDataBase _questDataBase;
    public static Dictionary<int, StructQuestData> Quests { get => QuestDataBase.Quests; }

    private static PlayerDataBase _playerDataBase;
    public static Dictionary<int, StructPlayerData> Players { get => PlayerDataBase.Players; }

    private static MonsterDataBase _monsterDataBase;

    public static Dictionary<int, StructMonsterData> Monsters { get => MonsterDataBase.Monsters; }
    public static Dictionary<int, GameObject> MonsterPrefabs { get => MonsterDataBase.MonsterPrefabs; }

    private static DialogDataBase _dialogDataBase;

    public static Dictionary<int, StructDialogData> Dialogs { get => DialogDataBase.Dialogs; }
    private static void Load()
    {
        _itemDataBase.Load();
        _npcDataBase.Load();
        _questDataBase.Load();
        _playerDataBase.Load();
        _monsterDataBase.Load();
        _dialogDataBase.Load();

    }

    public static void Initialize()
    {
        _itemDataBase = (ItemDataBase)(new ItemDataBase().Initialize());
        _npcDataBase = (NpcDataBase)(new NpcDataBase().Initialize());
        _questDataBase = (QuestDataBase)(new QuestDataBase().Initialize());
        _playerDataBase = (PlayerDataBase)(new PlayerDataBase().Initialize());
        _monsterDataBase = (MonsterDataBase)(new MonsterDataBase().Initialize());
        _dialogDataBase = (DialogDataBase)(new DialogDataBase().Initialize());

        Load();
    }
}


