using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace RPG.Common
{
    [Serializable]
    public struct StructInventory
    {
        public StructInventorySlot[] Items;
        public int InventorySlotNumber;
        public int Money;
        public int MaxMoney;
        public override string ToString()
        {
            return $"Items : [{string.Join(", ", Items)}, Money:{Money}]\n" +
                $"InventorySlotNumber : {InventorySlotNumber}, MaxMoney : {MaxMoney}";
        }
    }
}