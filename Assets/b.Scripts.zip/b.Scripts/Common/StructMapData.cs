//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using System;

//namespace RPG.Common
//{
//    [Serializable]
//    public struct StructMapData
//    {
//        public int Id;
//        public string Name;

//        public int[] MonsterIds;
//        public float[] MonsterPointX;
//        public float[] MonsterPointY;
//        public float[] MonsterPointZ;
//        public float[] MonsterRespawnTime;
//    }
//}