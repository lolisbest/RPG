//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//namespace RPG.Common
//{ 
//    public enum SlotType
//    {
//        None = 0,
//        Item,
//        Skill,
//    }
//}