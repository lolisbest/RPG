using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace RPG.Common
{
    [Serializable]
    public struct StructStatus
    {
        public string Name;

        public int Str;
        public int End;
        public int Sta;
        public int Mag;

        public string ActorType;

        public int Level;

        public int Experience;

        public override string ToString()
        {
            return $"Name : {Name}, Str : {Str}, ActorType: {ActorType}";
        }

        public void SetExperience(int exp)
        {
            Experience = exp;
        }
    }

    [Serializable]
    public struct StructHumanEquipSlots
    {
        public int HeadIndex;
        public int ChestIndex;
        public int HandIndex0;
        public int HandIndex1;
        public int FootIndex;

        public override string ToString()
        {
            return $"---- Player Equiments---\n" +
                $"HeadIndex : {HeadIndex}\n" +
                $"ChestIndex : {ChestIndex}\n" +
                $"HandIndex0: {HandIndex0}\n" +
                $"HandIndex1 : {HandIndex1}\n" +
                $"FootIndex : {FootIndex}";
        }
    }

    /// <summary>
    /// Player Status, StructInventory
    /// </summary>
    [Serializable]
    public struct StructPlayerData
    {
        public StructStatus Status;

        public StructInventory Inventory;

        // 현재 착용 중인 장비 아이템 슬롯 번호 목록
        public StructHumanEquipSlots HumanEquipSlots;

        public override string ToString()
        {

            return $"---------- {Status.Name} ----------\n" +
                $"Status : {Status}\n" +
                $"Inventory : {Inventory}\n" +
                $"{HumanEquipSlots}\n" +
                $"----------------------------";
        }
    }
}