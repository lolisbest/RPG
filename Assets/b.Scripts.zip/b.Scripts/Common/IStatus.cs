using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace RPG.Common
{
    public interface IStatus
    {
        public StructStatus Status { get; }
        public int Atk { get; }
        public int Def { get; }
        public int MaxHp { get; }
        public int MaxMp { get; }

        public void UpdateStatus();
    }
}