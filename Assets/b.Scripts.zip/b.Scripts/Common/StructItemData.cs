using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

namespace RPG.Common
{
    [Serializable]
    public struct StructItemData
    {
        public string Name;
        public string TypeString;
        public string IconPath;
        public int Id;
        public Sprite @Sprite;
        public ItemType @Type;
        
        public string Description;

        public int Attack;
        public int Defence;
        public int MaxHp;
        public int MaxMp;

        public int Str;
        public int End;
        public int Sta;
        public int Mag;

        public int RecoveryHpAmount;
        public int RecoveryMpAmount;

        public string EquipPartTypeString;
        public EquipType EquipPartType;

        public override string ToString()
        {
            return $"------- {Name} -------\n" +
                $"TypeString:{TypeString}\n" +
                $"IconPath:{IconPath}\n" +
                $"Id:{Id}\n" +
                $"Sprite:{@Sprite}\n" +
                $"ItemType:{@Type}\n" +
                $"EquipPartTypeString:{EquipPartTypeString}\n" +
                $"EquipPartType:{EquipPartType}\n" +
                $"-------------------";
        }

        public void LoadSprite()
        {
            if (@Sprite == null)
            {
                @Sprite = Resources.Load<Sprite>(IconPath);
            }
        }

        public void SetType()
        {
            @Type = RPG.Utils.EnumParse.StringToEnum<ItemType>(TypeString);
            if(EquipPartTypeString == null)
            {
                EquipPartType = EquipType.None;
            }
            else
            {
                EquipPartType = RPG.Utils.EnumParse.StringToEnum<EquipType>(EquipPartTypeString);
            }
        }
    }

    public enum ItemType
    {
        None = 0,
        Equipment,
        Consumable,
        Currency,
        Etc,
    }

    public enum EquipType
    {
        None = 0,
        Head,
        Chest,
        Hand0,
        Hand1,
        Foot,
    }
}