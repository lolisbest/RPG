using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using RPG.Common;
using System.Linq;

namespace RPG.UI
{
    public class QuestSelectionWindow : MonoBehaviour
    {
        public GameObject QuestSlotPrefab;
        public List<NpcQuestSlot> Slots;
        public RectTransform SlotsRoot;
        private readonly int _defaultCount = 10;

        // Awake 를 구현하지 않음. Initialize가 있기 때문에 Slots이나 QuestIds 초기화를 2번 할 수도 있음

        public void Initialize()
        {
            Slots = new();

            for (int i = 0; i < _defaultCount; i++)
            {
                AppendQuestSlot();
            }
        }

        private void AppendQuestSlot()
        {
            //Debug.Log("AppendQuestSlot");
            GameObject questSlotObject = Instantiate(QuestSlotPrefab);
            NpcQuestSlot questSlot = questSlotObject.GetComponent<NpcQuestSlot>();
            questSlotObject.transform.SetParent(SlotsRoot);
            Slots.Add(questSlot);
            questSlotObject.SetActive(false);
        }
        private void ClearQuestSlot()
        {
            foreach(var slot in Slots)
            {
                slot.InitializeText();
            }
        }

        public void UpdateQuest(int[] questIds)
        {
            ClearQuestSlot();

            if (questIds.Length > Slots.Count)
                ExtendSlots(questIds.Length - Slots.Count);

            for (int slotIndex = 0; slotIndex < questIds.Length; slotIndex++)
            {
                if(slotIndex < questIds.Length)
                {
                    StructQuestData questData = DataBase.Quests[questIds[slotIndex]];

                    Slots[slotIndex].SetInfo(questData.Id, questData.Title);
                    Slots[slotIndex].On();
                }
                else
                {
                    Slots[slotIndex].Off();
                }
            }
        }

        private void ExtendSlots(int number)
        {
            throw new System.NotImplementedException("ExtendSlots is not implemented");
        }

        public void Open()
        {
            gameObject.SetActive(true);
        }

        public void Close()
        {
            for (int slotIndex = 0; slotIndex < Slots.Count; slotIndex++)
            {
                Slots[slotIndex].Off();
            }

            gameObject.SetActive(false);
        }
    }
}