using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class StatusWindow : MonoBehaviour
{
    public Player @Player;

    public TextMeshProUGUI NameText;

    public TextMeshProUGUI StrText;
    public TextMeshProUGUI EndText;
    public TextMeshProUGUI StaText;
    public TextMeshProUGUI MagText;

    public TextMeshProUGUI AtkText;
    public TextMeshProUGUI DefText;
    public TextMeshProUGUI MaxHpText;
    public TextMeshProUGUI MaxMpText;

    public TextMeshProUGUI LefPointsText;

    private readonly string StrBaseString = "Str : {0}";
    private readonly string EndBaseString = "End : {0}";
    private readonly string StaBaseString = "Sta : {0}";
    private readonly string MagBaseString = "Mag : {0}";

    private readonly string AtkBaseString = "Attack : {0}";
    private readonly string DefBaseString = "Defence : {0}";
    private readonly string MaxHpBaseString = "MaxHp : {0}";
    private readonly string MaxMpBaseString = "MaxMp : {0}";

    private readonly string LeftPointsBaseString = "Left Status Points : {0}";


    void Start()
    {
        @Player = Player.Instance;
    }

    public void Open()
    {
        if(@Player == null)
        {
            @Player = Player.Instance;
        }
        UpdateStatusInfo();
        gameObject.SetActive(true);
    }

    public void Close()
    {
        gameObject.SetActive(false);
    }

    void Update()
    {
        if(@Player.IsChangedStatus)
        {
            Debug.Log("UpdateStatusInfo");
            UpdateStatusInfo();
            @Player.IsChangedStatus = false;
        }
    }

    private void UpdateStatusInfo()
    {
        NameText.text = @Player.Status.Name;

        StrText.text = string.Format(StrBaseString, @Player.TotalStr);
        EndText.text = string.Format(EndBaseString, @Player.TotalEnd);
        StaText.text = string.Format(StaBaseString, @Player.TotalSta);
        MagText.text = string.Format(MagBaseString, @Player.TotalMag);

        AtkText.text = string.Format(AtkBaseString, @Player.Atk);
        DefText.text = string.Format(DefBaseString, @Player.Def);
        MaxHpText.text = string.Format(MaxHpBaseString, @Player.MaxHp);
        MaxMpText.text = string.Format(MaxMpBaseString, @Player.MaxMp);

        //LefPointsText.text = string.Format(LeftPointsBaseString, );
    }
}
