using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace RPG.UI
{
    public partial class IconSkillSlot : MonoBehaviour
    {
        public Image SkillIcon;
        public int SkillId;

        public void SetFloatingIconSize(Vector2 size)
        {

        }

        public void ResetFloatingIconSize()
        {

        }
    }
}