using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using RPG.Common;
using System.Linq;
using TMPro;

public class NpcServiceSelectionWindow : MonoBehaviour
{
    //public List<Button> Buttons;
    public Dictionary<NpcService, Button> Buttons;
    public TextMeshProUGUI NpcNameText;
    public GameObject ButtonsRoot;

    public void Initialize()
    {
        Buttons = new();
        Button[] childButtons = ButtonsRoot.GetComponentsInChildren<Button>();

        foreach (var serviceString in System.Enum.GetNames(typeof(NpcService)))
        {
            NpcService service = RPG.Utils.EnumParse.StringToEnum<NpcService>(serviceString);
            Buttons.Add(service, null);
        }

        foreach(var childButton in childButtons)
        {
            if (childButton.name == "Quit")
                continue;

            // ���� ��ư�� �ǳڷ� ����������
            // �⺻������ ��Ȱ��ȭ. Content Size Fitter ������Ʈ�� ����
            childButton.transform.parent.gameObject.SetActive(false);

            // ������ Enum ���� ���ڿ��� ��ư�� �̸��� ���ԵǴ��� => �ٸ����� ��������
            if (!System.Enum.GetNames(typeof(NpcService)).Any(childButton.name.Contains))
                continue;

            NpcService buttonService = RPG.Utils.EnumParse.StringToEnum<NpcService>(childButton.name);
            if (Buttons.ContainsKey(RPG.Utils.EnumParse.StringToEnum<NpcService>(childButton.name)))
            {
                Buttons[buttonService] = childButton;
            }
            
            
        }
    }

    public void SetNpcName(string name)
    {
        NpcNameText.text = name;
    }

    public void SetServices(NpcService services)
    {
        foreach(var serviceString in System.Enum.GetNames(typeof(NpcService)))
        {
            NpcService service = RPG.Utils.EnumParse.StringToEnum<NpcService>(serviceString);

            if (services.HasFlag(service) && Buttons[service] != null)
            {
                // ���� ��ư�� �ǳڷ� ����������
                Buttons[service].transform.parent.gameObject.SetActive(true);
            }
        }
    }

    public void Close()
    {
        foreach(KeyValuePair<NpcService, Button> item in Buttons)
        {
            // ���� ��ư�� �ǳڷ� ����������
            item.Value.transform.parent.gameObject.SetActive(false);
        }

        gameObject.SetActive(false);
    }

    public void Open()
    {
        gameObject.SetActive(true);
    }
}
